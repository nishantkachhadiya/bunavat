import React from 'react'
import { Link } from 'react-router-dom'

const Product = () => {
    return (
        <div className='product_page'>
            <div className='product_slider_section'>
                <div className='row'>
                    <div className='col-md-6 product_info_section_wrap'>
                        <div className='product_info_section'>
                            <div className='product_title_wrap'>
                                <h2>Brocade Kurta</h2>
                                <div className='saved_wrap'>
                                    <span>Save</span>
                                    <svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M8.77149 14.6606L6.27724 16.6776C5.15329 17.586 3.54435 16.4235 4.06783 15.0686L5.21488 12.074C5.45353 11.4504 5.22258 10.7422 4.6683 10.3804L1.98159 8.63286C0.765261 7.84764 1.38113 5.95386 2.82841 6.03084L6.0309 6.2002C6.70065 6.23869 7.30112 5.79989 7.47048 5.15323L8.3019 2.05082C8.67911 0.649727 10.6576 0.649727 11.0348 2.05082L11.8662 5.15323C12.0356 5.79989 12.636 6.231 13.3058 6.2002L16.5083 6.03084C17.9556 5.95386 18.5637 7.83994 17.3551 8.63286L14.6684 10.3804C14.1064 10.7422 13.8755 11.4504 14.1218 12.074L15.2689 15.0686C15.7846 16.4235 14.1834 17.586 13.0594 16.6776L10.5652 14.6606C10.0494 14.2372 9.30268 14.2372 8.78689 14.6606H8.77149Z" stroke="#2A3990" stroke-width="1.7" stroke-miterlimit="10" />
                                    </svg>
                                </div>
                            </div>
                            <div className='common_product_details'>
                                <div>Gold embroidered</div>
                                <div>Lycra & cotton fabric</div>
                                <div>Slim fit with flared bottom</div>
                                <div>Made in Udaipur</div>
                                <div>Club members get 10% off. Join</div>
                                <div>
                                    <Link>
                                        Get help on Whatsapp
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_1187_4489)">
                                                <path d="M0.814453 1.15381H10.8461V11.1855" stroke="#2A3592" stroke-width="1.7" stroke-miterlimit="10" />
                                                <path d="M0.814453 11.1855L10.8461 1.15381" stroke="#2A3592" stroke-width="1.7" stroke-miterlimit="10" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_1187_4489">
                                                    <rect width="12" height="12" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </Link>
                                    10am—6pm
                                </div>
                                <div>
                                    <Link>
                                        See it live
                                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_1187_4489)">
                                                <path d="M0.814453 1.15381H10.8461V11.1855" stroke="#2A3592" stroke-width="1.7" stroke-miterlimit="10" />
                                                <path d="M0.814453 11.1855L10.8461 1.15381" stroke="#2A3592" stroke-width="1.7" stroke-miterlimit="10" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_1187_4489">
                                                    <rect width="12" height="12" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </Link>
                                    Next slot at 4:15pm
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-6'>

                    </div>
                </div>
            </div>
        </div>
    )
}

export default Product