import React from 'react'
import '../assets/scss/module/_loader.scss'

const Loader = () => {
    return (
        <div className="circle-loader"></div>
    )
}

export default Loader